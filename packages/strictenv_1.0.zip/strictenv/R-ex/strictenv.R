### Name: strictenv
### Title: Strict Environments
### Aliases: strictenv as.strictenv $.strictenv [.strictenv [[.strictenv
###   $<-.strictenv ^<- ^<-.strictenv [<-.strictenv [[<-.strictenv \%$\%<-
###   \%$!\%<- \%in\% as.list.strictenv c.strictenv names.strictenv
###   names<-.strictenv
### Keywords: data misc

### ** Examples

## create a strict environment directly
se <- strictenv(x=1, y=2)

## create a strictenv from a list with named items
lst <- list(a=45, .b="blatto")
se <- as.strictenv(lst)

## create a strictenv that inherits from an existing one

se2 <- strictenv (c=23, PARENT=se)

## use the value of an inherited symbol

se2$a + 3

## make a local copy of an inherited symbol

se2$a <- 10

## the ancestor object retains the original symbol binding
se$a != se2$a

## remove the local copy of an inherited symbol
se2["a"] <- NULL
se$a != se2$a

## change the ancestral binding of an inherited symbol
se2^a <- "some new value"
se$a == se2$a

## set the list of existing symbols in a strict environment
## (new symbols are bound to NULL; existing ones are left unchanged)
names(se) <- c(names(se), "me", "metoo")

## combine a strict environment with new bindings
se <- c(se, eee="help", sos="help faster", list(extra="stuff"))

## return the value of a symbol
se$a
se[[".b"]]

## assign a new value to a symbol
se$.b <- "new blatto"

## add and bind a new symbol
se%$%funny <- "joke"
se[["more.funny", NEW=TRUE]] <- "two jokes"

## bind a symbol, creating it if it does not exist
se%$!%funny <- "punchline"
se[["even.more.funny", FORCE=TRUE]] <- "three jokes"

## subset with a character vector, showing a strictenv behaving
## more like a list than an environment
se[c("funny", "even.more.funny")]

## assignment to a subset, showing a strictenv behaving
## more like a list than an environment
se[c("funny", "even.more.funny")] <- list(1:10, "some stuff")

## addition of new symbols from other sources to a strictenv
c(se, aaa="before the rest", list(pi=3, e=2), bbb="again")

## addition of new symbols and rebinding of existing symbols 
c(se, aaa="first try", list(aaa="second try"), FORCE=TRUE)

## list elements
ls(se)    # will not list symbols beginning with "."
names(se) # list all symbols

## error upon look up of non-existent symbol
## Not run: se$f
## Not run: se[["g"]]

## error upon attempt to implicitly create a new symbol
## Not run: se$f <- 1:10
## Not run: se[["g"]] <- "won't work"

## error upon attempt to explicitly create new symbol
## when it already exists
## Not run: se%$%funny <- "not so much"
## Not run: se[["even.more.funny", NEW=TRUE]] <- "bad jokes"

## test for existence of a symbol
"g"  %in% se    # returns FALSE
".b" %in% se    # returns TRUE




