### Name: extmat
### Title: extmat - large non-copying matrices of fixed-sized elements
### Aliases: extmat as.character.extmat as.vector.extmat dim.extmat
###   dim<-.extmat format.extmat length.extmat length<-.extmat name
###   name.extmat name<- name<-.extmat pointer pointer.extmat print.extmat
###   zero zero.extmat [.extmat [<-.extmat extmat.sizes extmat.types
### Keywords: data array

### ** Examples




