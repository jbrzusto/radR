### Name: bigframe
### Title: bigframe - disk-backed data frames with fixed row size
### Aliases: bigframe bigframe.default.cache.size bigframe.header.string
###   bigframe.type.sizes close.bigframe dim<-.bigframe dim.bigframe
###   flush.bigframe length.bigframe names.bigframe print.bigframe
###   rbind.bigframe [<-.bigframe [.bigframe [[.bigframe $<-.bigframe
###   $.bigframe
### Keywords: data array

### ** Examples




