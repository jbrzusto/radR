### Name: biglist
### Title: biglist - simple disk-based lists of arbitrary R objects
### Aliases: biglist biglist.default.cache.size biglist.header.string
###   biglist.indexfile.suffix c.biglist close.biglist drop.items
###   flush.biglist length<-.biglist length.biglist names.biglist
###   print.biglist [[.biglist [[<-.biglist [.biglist
### Keywords: data array

### ** Examples




